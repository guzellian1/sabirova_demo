﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace sabirova_demo
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            string login = TextLogin.Text;
            string password = TextPass.Text;
            if (login.Length == 0)
            {
                MessageBox.Show("Поле логина не должно быть пустым");

            }
            else if (password.Length == 0)
            {
                MessageBox.Show("Поле пароля не должно быть пустым");

            }

            else
            {
                Users users;
                using (sabirova_demoEntities db = new sabirova_demoEntities())
                {
                    users = db.Users.Where(b => b.login == login && b.password == password).FirstOrDefault();
                }
                if (users.role == "Студент")
                {
                    if (users != null)
                    {
                        MessageBox.Show("Вход выполнен");
                        StudentWindow studentWindow = new StudentWindow(users);
                        studentWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");

                    }
                }
                if (users.role == "Преподаватель")
                {
                    if (users != null)
                    {
                        MessageBox.Show("Вход выполнен");
                        TeacherWindow teacherWindow = new TeacherWindow(users);
                        teacherWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");

                    }
                }

                if (users.role == "Администратор")
                {
                    if (users != null)
                    {
                        MessageBox.Show("Вход выполнен");
                        AdminWindow adminWindow = new AdminWindow(users);
                        adminWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");

                    }
                }


            }
        }
    }
}
