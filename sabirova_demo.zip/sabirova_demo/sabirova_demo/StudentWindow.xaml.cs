﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace sabirova_demo
{
    /// <summary>
    /// Логика взаимодействия для StudentWindow.xaml
    /// </summary>
    public partial class StudentWindow : Window
    {

        Users user = new Users();
        public Student currentStudent = new Student();
        public StudentWindow(Users NewUser)
        {
            user = NewUser;
            InitializeComponent();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow authorizationWindow = new AuthorizationWindow();
            authorizationWindow.Show();
            this.Close();
        }

        private void Show_Attestation(object sender, RoutedEventArgs e)
        {
            DataGridProgress.ItemsSource = sabirova_demoEntities.GetContext().Attestations.ToList();
        }

        private void Show_Info(object sender, DependencyPropertyChangedEventArgs e)
        {
            //currentStudent = sabirova_demoEntities.GetContext().Student.Where(b => b.user_id == user.user_id).FirstOrDefault();
            //stud.Text = "ФИО: " + currentStudent.name;
            //Groups group = new Groups();
            //group = sabirova_demoEntities.GetContext().Groups.Where(b => b.group_id == currentStudent.group_id).FirstOrDefault();
            //GroupStud.Text = "Номер группы: " + group.number;
        }
    }
}
